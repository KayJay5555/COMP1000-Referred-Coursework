#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <regex>
#include <map>
#include <string>
using namespace std;

//See bottom of main
int findArg(int argc, char* argv[], string pattern);

int readFileIntoString(string fn, string& allLines);


//string matchedresult(int matchedResultNumber, int wordNumber, int lineNumber);
/*
 *
 * The user can launch application as follows:
 *
 * TaskA <filename> <search term> [-regex]
 *
 * <database file>              REQUIRED. Specifies the file to search (required). This is ALWAYS the first parameter. The file must exist in order to be searched
 * <search term>                REQUIRED. The search term as either a single word or a regular expression.
                                This is a single word, made up of alpha-numeric characters only.
 * -regex                       OPTIONAL. If this flag is present, then the search term is a regular expression (as opposed to a single word).
                                It must be a valid regex expression.
 *
 * ****************
 * *** EXAMPLES ***
 * ****************
 *
 * TaskA lorum.txt comp1000             Searches for the string comp1000 in the file lorum.txt
 * TaskA lorum.txt "^(\\d)\\d" -regex   Searches the file lorum.txt for all patterns that match the regular expression "^(\\d)\\d"
 * TaskA lorum.txt -regex "^(\\d)\\d"   Searches the file lorum.txt for all patterns that match the regular expression "^(\\d)\\d"
 * TaskA lorum.txt                      Error - search expression provided
 *
 * *************
 * *** NOTES ***
 * *************
 *
 * o Try to write your code such that is can be reused in other tasks.
 * o Code should be consistently indented and commented
 * o Consider error conditions, such as missing parameters or non-existent files
*/


int main(int argc, char* argv[])
{
    // argv is an array of strings, where argv[0] is the path to the program, argv[1] is the first parameter, ...
    // argc is the number of strings in the array argv
    // These are passed to the application as command line arguments
    // Return value should be EXIT_FAILURE if the application exited with any form of error, or EXIT_SUCCESS otherwise


    //A string to hold the contents of the file
    string dataString;
    //Reads file into the string and outputs a number to determine success
    int errCode = readFileIntoString(argv[2], dataString);
    // If successful, display contents
    if (errCode != 0) {
        cerr << "Error: " << errCode << endl;
        return errCode;
    }

    //Display the string
    cout << dataString << endl;

    // Read line-by-line (separated by newline)
    istringstream iss(dataString);
    string nextLine;
    string allLines;
    int lineNumber = 0;
    int linesMax = 0;
    float wordNumber = 0;
    float successfulSearches = 0;
    vector<string> lines;
    vector<string> resultNumber;

    //Use a loop to read all remaining lines
    do {
        getline(iss, nextLine);
        if (nextLine.empty()) {
            continue;
            continue;
        }

        //Did we successfully read a line?
        if (!iss.fail()) {
            //If so, append to the string `allLines` and add a newline character on the end
            //lineNumber++;
            linesMax++;
            //cout << "Read in the line: " << nextLine << " Line number: " << lineNumber << endl;
            allLines = allLines + nextLine + "\n";
            lines.push_back(nextLine);
        }

    } while (!iss.eof());   //Loop condition is if we have NOT reached the end of the file

    for (int i = 0; i < linesMax; i++) {
        //cout << "Line: " << i+1 << " = " << lines[i] << endl << endl;
        lineNumber++;
        // Parse String word by word
        istringstream iss(lines[i]);

        // Read the next word
        string nextWord;
    
        while (iss.eof() == false)
        {
            //Try to read the next word
            iss >> nextWord;
            if (iss.fail()) {
                //Jump to the end of the while loop
                continue;
                continue;
            }
            // Display the word
            wordNumber++;
            //cout << "Next Word: " << nextWord << "' |  Word Number: " << wordNumber << " | Line Number: " << lineNumber << endl;

            //Look for the searched string
            if (nextWord == argv[3]) {
                //Increments the number of successful searches and outputs the data for the search
                successfulSearches++;
                cout << "Found '" << argv[3] << "' | Matched Result Number: " << successfulSearches << " |  Word Number: " << wordNumber << " | Line Number: " << lineNumber << endl;
               
            }
        }
    }

    //This calculates the percentage of matched results over total number of words 
    float hitPercentage = ((successfulSearches / wordNumber) * 100);
    cout << "The percentage of matched results over total number of words is: " << hitPercentage << endl;


    // Open for write
    ofstream outputStream;
    outputStream.open("results.csv", ios::app);
    if (!outputStream.is_open()) {
        cerr << "Cannot create file" << endl;
        return -1;
    }

    // Stream characters
    outputStream << "File Name: " << argv[2] << ", Search Term: " << argv[3] << ", Frequency of hits: " << hitPercentage << endl;

    // Close
    outputStream.close();

    if (argc == 3) {
        //Welcome message
        cout << "TaskA (c)2024" << endl;

        //BASIC EXAMPLE: Get parameters for the simple case
        string fileName(argv[1]);
        string searchString(argv[2]);

        //Confirm
        cout << "TaskA " << fileName << " " << searchString << endl;

        //Done
        return EXIT_SUCCESS;
    }

    //EXAMPLE: Scan command line for -regex switch
    int p = findArg(argc, argv, "-regex");
    if (p) {
        cout << "The search term is a regular expression. See https://www.softwaretestinghelp.com/regex-in-cpp/ for examples of how to do this " << endl;
    }

    //**************************************************************
    //You could continue here :)
    //**************************************************************

    


    return EXIT_SUCCESS;
}

// Find an argument on the command line and return the location
int findArg(int argc, char* argv[], string pattern)
{
    for (int n = 1; n < argc; n++) {
        string s1(argv[n]);
        if (s1 == pattern) {
            return n;
        }
    }
    return 0;
}

// Read the test file into a string
int readFileIntoString(string fn, string& allLines)
{
    // Open for read
    ifstream inputStream;
    inputStream.open(fn);
    if (!inputStream.is_open()) {
        cerr << "Cannot open file " << fn << endl;
        return -1;
    }

    // Read line-by-line (separated by newline)
    string nextLine;    //String to hold each line
    allLines = "";      //Reset to empty string
    int lineNumber;
    //Use a loop to read all remaining lines
    do {
        //Read a line from the stream `inputString` into the string `nextLine`
        getline(inputStream, nextLine);

        //Did we successfully read a line?
        if (!inputStream.fail()) {
            //If so, append to the string `allLines` and add a newline character on the end
            allLines = allLines + nextLine + "\n";
        }
        //The last read MIGHT include an EOF character
    } while (!inputStream.eof());   //Loops condition if we have NOT reached the end of the file

    // Closes the file
    inputStream.close();

    return 0;
}
